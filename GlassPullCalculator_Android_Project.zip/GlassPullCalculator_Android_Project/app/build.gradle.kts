plugins { id("com.android.application") }

android {
    namespace = "com.kiam.glasspull"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.kiam.glasspull"
        minSdk = 23
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }
}
